<?php
   include 'connection.php';
   
   class Title {
       public $title;
       public $startDate;
       public $endDate;
   }
   
   $dataList = array();
   $result = 0;
   $where =1;
   if(isset($_POST['view'])){
       
       $title=$_POST["title"];
       $startDate=$_POST["startDate"];
       $endDate=$_POST["endDate"];
       if(!empty($title)){$where=$where." AND title LIKE '%$title%'";}
       if(!empty($startDate) && empty($endDate)){$where=$where." AND startDate = '".$startDate."'";}
       if(!empty($endDate) && empty($startDate)){$where=$where." AND endDate = '".$endDate."'";}
       if(!empty($startDate) && !empty($endDate)){
        $where=$where." AND startDate >= '".$startDate."' AND endDate <= '".$endDate."'";
       }
       $sql = "SELECT * FROM title_table WHERE $where order by id Desc";
    }else{
       $sql="SELECT * from title_table order by id Desc";
   }
       $result = $conn->query($sql);
       if ($result->num_rows != 0) {
           $i = 0;
           while($row = $result->fetch_assoc()) {
               $dataList[$i] = new Title();
               $dataList[$i]->title = $row['title'];
               $dataList[$i]->startDate = $row['startDate'];
               $dataList[$i]->endDate = $row['endDate'];
               $i++;
           }
   
           $result = 1;
       }
   
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet">
      <link href="./css/custom.css" rel="stylesheet">
      <title>View Page</title>
   </head>
   <body>
      <!-- Navbar Start -->
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
         <div class="container-fluid">
            <a class="navbar-brand" href="./index.php">PHP Assignment</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
               <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                  <li class="nav-item">
                     <a class="nav-link active" aria-current="page" href="./index.php">Home Page</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="./add.php">Add</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="./view.php">View and Search</a>
                  </li>
               </ul>
            </div>
         </div>
      </nav>
      <!-- Navbar End -->
      <!-- Wrapper Start -->
      <div class="wrapper">
         <!-- Display Container Start -->
         <?php
            if($result) {
            ?>
         <section class="display-section px-3 py-5">
            <h3 class="text-secondary mb-5 text-center">Data List</h3>
            <form method="POST">
               <div class="input-group mb-3">
                  <input type="text" class="form-control" id="title" name="title" placeholder="Enter String to search"/>
                  <input type="date" class="form-control" id="startDate" name="startDate"  placeholder="Enter Start Date" >
                  <input type="date" class="form-control" id="endDate" name="endDate"  placeholder="Enter End Date" >
                  <button type="submit" name="view" class="btn btn-dark">Search</button>
               </div>
            </form>
            <table class="bg-dark text-light mx-auto">
               <tr>
                  <th class="bg-warning text-dark">ID</th>
                  <th class="bg-warning text-dark">title</th>
                  <th class="bg-warning text-dark optional">Start Date</th>
                  <th class="bg-warning text-dark optional">End Date</th>
               </tr>
               <?php
                  if(!empty($dataList)){
                      $i=1;
                      foreach($dataList as $std) {
                          echo '<tr>';
                              echo '<td>' . $i . '</td>';
                              echo '<td>' . $std->title . '</td>';
                              echo '<td class="optional">' . $std->startDate . '</td>';
                              echo '<td class="optional">' . $std->endDate . '</td>';
                          echo '</tr>';
                          $i++;
                      }
                  }else{
                     echo '<tr><td  colspan="4">No Matching Data Found</td></tr>'; 
                  }
                  ?>
            </table>
         </section>
         <?php
            }
            ?>
         <!-- Display Container End -->
      </div>
      <!-- Wrapper End -->
      <!-- Footer Start -->
      <footer class="bg-dark">
         <p class="text-light text-center pt-4">&copy;Anju Upadhyay</p>
      </footer>
      <!-- Footer End -->
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"></script>
   </body>
</html>